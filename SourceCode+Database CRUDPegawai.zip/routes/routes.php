//Nama      = Rafly Maulana Zulyzar
//NIM       = 10122790
//Fakultas  = Teknik dan Ilmu Komputer
//Jurusan   = Teknik Informatika
//Kelas     = IF-4/V