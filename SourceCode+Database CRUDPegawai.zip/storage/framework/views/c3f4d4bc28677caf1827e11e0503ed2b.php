<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="css/style1.css" />
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=abeezee:400" rel="stylesheet" />
        <style>
            body{
                font-family: 'ABeeZee', sans-serif;
            }
            
            header{
                font-family: 'ABeeZee', sans-serif;
            }

        </style>

        <!--[if lt IE 9]>
        <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <title>MyWeb</title>
    </head>
    <!--[if IE 6 ]><body class="ie6 old_ie"><![endif]-->
    <!--[if IE 7 ]><body class="ie7 old_ie"><![endif]-->
    <!--[if IE 8 ]><body class="ie8"><![endif]-->
    <!--[if IE 9 ]><body class="ie9"><![endif]-->
    <!--[if !IE]><!--><body><!--<![endif]-->
		<header>
			<h1><a class="nav-link" href="<?php echo e(route('home')); ?>">My Web</a></h1>
			<nav>
				<ul>
					<li><a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a></li>
					<li><a class="nav-link" href="<?php echo e(route('about')); ?>">About</a></li>
                    <li><a class="btn btn-primary" href="<?php echo e(route('actionlogout')); ?>">Logout</a>
				</ul>
			</nav>
		</header>
		

<!-- Begin Page Content -->
<div class="container-fluid">
<br>
<br>
<?php echo $__env->yieldContent('konten'); ?>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

		
</html>
		
		
			
    
    <?php /**PATH C:\xampp\htdocs\10122790\utslara\resources\views/master.blade.php ENDPATH**/ ?>