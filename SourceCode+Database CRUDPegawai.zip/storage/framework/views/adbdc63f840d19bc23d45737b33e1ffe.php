

<?php $__env->startSection('konten'); ?>

<style>
		body {
        	background-color: #a9a9a9; 
   		}
            
		secwrapper {
        background-color: #a9a9a9; 
    	}

		article {
        background-color: #000000; 
        color: #FFA500; 
        margin-bottom: 20px; 
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
    }
</style>

<br>
<div id="secwrapper">
			<section>
				<article id="featured">
					<a href="<?php echo e(route('artikel1')); ?>"><img src="img/gta6.jpeg" alt=""/></a>
					
					<h1>ROCKSTAR MERILIS TRAILER PERTAMA GTA 6</h1>
					<br>
					<p>Pada tanggal 5 desember kemarin, Rockstar telah official merilis trailer GTA 6
					pertama mereka. Tentu saja hal ini membuat seluruh gamer di dunia heboh dikarenakan
					seri yang ke 6 ini sangat ditunggu setelah...</p>
					<a href="<?php echo e(route('artikel1')); ?>" class="readmore">Read more</a>
				</article>
				<article>
					<a href="<?php echo e(route('artikel2')); ?>"><img src="img/T1.jpeg" style = "width : 100%;" alt=""/></a>
					<h1>T1 KEMBALI MENJUARAI LOL WORLD 2023 </h1>
					<br>
					<p>Team esport asal korea, T1 kembali menjuarai turnamen League of Legend yang paling bergengsi
						yaitu WORLD 2023 kemarin setelah menjani runner up pada tahun 2022 kemarin.
						Banyak fans di seluruh dunia sangat bahagia karena...
					</p>
					<a href="<?php echo e(route('artikel2')); ?>" class="readmore">Read more</a>
				</article>
				<article class="rightcl">
					<a href="<?php echo e(route('artikel3')); ?>"><img src="img/Faker.jpeg" alt=""/></a>
					<h1>FAKER RESMI MENJADI GOAT DI LEAGUE OF LEGEND</h1>
					<br>
					<p>Setelah menjuarai memenangkan WORLD 2023, Lee "FAKER" Sang-Hyeok telah resmi menjadi GOAT dari game league
						of legend dikarenakan sejauh ini hanya dia yang sebagai player
						esport LOL yang memenangkan WORLD sebanyak ...
					</p>
					<a href="<?php echo e(route('artikel3')); ?>" class="readmore">Read more</a>
				</article>			
				<article>
					<a href="<?php echo e(route('artikel4')); ?>"><img src="img/asfthu.webp" style = "width : 100%; alt="></a>
					<h1>A SPACE FOR THE UNBOUND MASUK NOMINASI THE GAME AWARDS 2023</h1>
					<br>
					<p>A space for the unbound masuk nominasi Game Awards 2023. Game yang dibuat
						oleh developer asal indonesia ini masuk nominasi "Games  For Impact" yang dimana 
						pada kategori ini game dianggap berhasil menyampaikan makna atau mo... 
					</p>
					<a href="<?php echo e(route('artikel4')); ?>" class="readmore">Read more</a>
				</article>
				
				<article>
					<a href="<?php echo e(route('artikel5')); ?>"><img src="img/goty.jpeg" style = "width : 100%;" alt=""/></a>
					<h1>THE GAME AWARDS 2023 RESMI SELESAI</h1>
					<br>
					<p>Event industri video game ternama yaitu The Game Awards 2023 sudah resmi selesai.
						The Game Awards sendiri digelar pada tanggal 7 Desember 2023 di Los Angeles, Amerika Serikat.
						Ada beberapa hal menarik yang ter...
					 </p>
					<a href="<?php echo e(route('artikel5')); ?>" class="readmore">Read more</a>
				</article>
				<article class="rightcl">
					<a href="<?php echo e(route('artikel6')); ?>"><img src="img/god.jpeg" style = "width : 100%;" alt=""/></a>
					<br>
					<h1>NEWJEANS MERILIS SINGLE BERJUDUL "GODS" UNTUK WORLD 2023</h1>
					<p>NewJeans merilis single berjudul "GODS" untuk turnamen LOL bergengsi 
						yaitu WORLD 2023. Yang membuat lagu ini begitu hype dikarenakan lagu
						ini sendiri dinyanyikan oleh group K-POP terkenal yaitu....
					</p>
					<a href="<?php echo e(route('artikel6')); ?>" class="readmore">Read more</a>
				</article>
				
			</section>
		</div>
		<footer >
			<p>&copy by Rafly Maulana Zulyzar - 10122790 </p>
		</footer>
	</body>

            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\10122790\utslara\resources\views/home.blade.php ENDPATH**/ ?>