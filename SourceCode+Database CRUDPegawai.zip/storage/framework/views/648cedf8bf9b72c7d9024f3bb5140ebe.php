

<?php $__env->startSection('konten'); ?>

    <div>
        <center>
            <h1>Data Job</h1>
        </center>
        <center>
            <a href="<?php echo e(route('tambahJob')); ?>">+ &nbsp; Tambah Job</a>
            <br />
            <table>
                <thead>
                    <tr>
                        <th>ID Jobdesk</th>
                        <th>Nama Jobdesk</th>
                        <th>Bidang</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data_job; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($job->id_job); ?></td>
                        <td><?php echo e($job->job); ?></td>
                        <td><?php echo e($job->bidang); ?></td>
                        <td>
                            <a href="<?php echo e(route('editJob', ['id_job'=>$job->id_job])); ?>">Edit</a> |
                            <a href="<?php echo e(route('proses_hapusJob', ['id_job'=>$job->id_job])); ?>"
                                onclick="return confirm('Anda yakin akan menghapus data ini?')">Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </center>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\utslara\resources\views/job.blade.php ENDPATH**/ ?>