

<?php $__env->startSection('konten'); ?>
<style>
		body {
        	background-color: #a9a9a9;     
   		}

          
</style>

        </style>


<br>
<br>
<!-- Page Content Section -->
<div class="w3-content" style="max-width:2000px;margin-top:46px">

  <!-- Artikel Section -->
  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px; margin: auto;" id="band">

<div class="w3-card w3-padding">
    <h1 class="w3-wide">T1 KEMBALI MENJUARAI LOL WORLD 2023</h1>
    <hr>
    <p class="w3-opacity"><i>Dunia Video Game</i></p>
    
    <br>
    <br>

    <div class="w3-row">
        <div class="w3-half w3-padding">
            <p class="w3-justify">Team esport asal korea, T1 kembali menjuarai turnamen 
                League of Legend yang paling bergengsi yaitu WORLD 2023 kemarin setelah 
                menjani runner up pada tahun 2022 kemarin. Banyak fans di seluruh dunia 
                sangat bahagia karena setelah 7 tahun T1 belum mengangkat piala WORLD lagi 
            dan ditambah turnamen tahun ini diselenggarakan di Home Turf T1 yaitu Korea Selatan.</p>
            <br>
            <p class="w3-justify">Seperti  kita ketahui, T1 sebenarnya sudah tampil baik 
                sepanjang tahun, namun masih belum meraih gelar juara. LCK Spring-Summer 
                2023 T1 harus puas di posisi kedua setelah kalah dari Gen.G Esports. Mereka
                 kemudian harus puas menempati posisi ketiga di  Mid-Season Invitational  
                 setelah kalah dari BiliBili Gaming.</p>
                 <br>
            <p class="w3-justify">Di babak semifinal, T1 ditantang oleh JD Gaming yang sebelumnya 
                mengalahkan KT Rolster 3:1. Skor sempat 1-1, namun T1 terlihat mampu membaca 
                JDG sehingga menang 3-1. Final WORLD 2023 merupakan final keenam 
                yang pernah dilakukan Faker. Sebelumnya Faker berhasil memenangkan 3  final dan 
                kalah 2 kali. Kali ini, Faker kembali tampil impresif di final dan berhasil 
                meraih gelar juara ke-4 Worlds 2023, menegaskan bahwa tidak salah jika komunitas 
                League of Legends memberinya julukan "League of Legends God"; kepada seorang pria 
                bernama Lee Sang-hyeok alias "FAKER".</p>
                <br>
                <p class="w3-justify">Selain WORLD, Faker juga telah memenangkan banyak kejuaraan 
                    seperti  League of Legends Champions Korea (LCK) dan MSI.Yang patut ditiru oleh 
                    para pemain profesional lainnya dari Faker adalah semangatnya untuk selalu menjadi 
                    yang terbaik, sehingga rasa hausnya akan prestasi menjadikannya yang terhebat 
                    sepanjang masa (GOAT) di dunia esport terutama untuk game League of Legend.</p>
            

        </div>
        <div class="w3-half w3-padding" style="text-align: right;">
            <div class="mySlides w3-display-container w3-center">
                <img src="img/T1.jpeg" alt="Team T1 at World 2023" style="width:92%">
            </div>
            <br>
            <div class="mySlides w3-display-container w3-center">
                <img src="img/t1-worlds.gif" alt="T1 lift the trophy" style="width:92%">
            </div>
        </div>
    </div>
</div>

</div>

<style>
.w3-row {
    display: flex;
}

.w3-half {
    flex: 1;
}

.w3-card {
        background-color: #000; /* Matte Black */
        color: #FFA500; /* Orange */
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
    }
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\10122790\utslara\resources\views/artikel2.blade.php ENDPATH**/ ?>