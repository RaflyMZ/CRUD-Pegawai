

<?php $__env->startSection('konten'); ?>

    <div>
        <center>
            <h1>Data Pegawai</h1>
        </center>
        <center>
            <a href="<?php echo e(route('tambahPegawai')); ?>">+ &nbsp; Tambah Pegawai</a>
            <br />
            <table>
                <thead>
                    <tr>
                        <th>Id Pegawai</th>
                        <th>Nama Pegawai</th>
                        <th>Job</th>
                        <th>Jenis Kelamin</th>
                        <th>No Telepon</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data_pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pegawai->id_pegawai); ?></td>
                        <td><?php echo e($pegawai->nama_pegawai); ?></td>
                        <td><?php echo e($pegawai->job); ?></td>
                        <td><?php echo e($pegawai->jenis_kelamin); ?></td>
                        <td><?php echo e($pegawai->no_telepon); ?></td>
                        <td>
                            <a href="<?php echo e(route('editPegawai', ['id_pegawai'=>$pegawai->id_pegawai])); ?>">Edit</a> |
                            <a href="<?php echo e(route('proses_hapusPegawai', ['id_pegawai'=>$pegawai->id_pegawai])); ?>"
                                onclick="return confirm('Anda yakin akan menghapus data ini?')">Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </center>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\utslara\resources\views/pegawai.blade.php ENDPATH**/ ?>