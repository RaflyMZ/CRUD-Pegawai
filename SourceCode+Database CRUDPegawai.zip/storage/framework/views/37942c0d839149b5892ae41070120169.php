

<?php $__env->startSection('konten'); ?>
<style>
		body {
        	background-color: #a9a9a9;     
   		}

          
</style>

        </style>


<br>
<br>
<!-- Page Content Section -->
<div class="w3-content" style="max-width:2000px;margin-top:46px">

  <!-- Artikel Section -->
  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px; margin: auto;" id="band">

<div class="w3-card w3-padding">
    <h1 class="w3-wide">ROCKSTAR MERILIS TRAILER PERTAMA GTA 6</h1>
    <hr>
    <p class="w3-opacity"><i>Dunia Video Game</i></p>
    
    <br>
    <br>

    <div class="w3-row">
        <div class="w3-half w3-padding">
            <p class="w3-justify">Pada tanggal 5 desember kemarin, Rockstar telah official merilis trailer GTA 6
					pertama mereka. Tentu saja hal ini membuat seluruh gamer di dunia heboh dikarenakan
					seri yang ke 6 ini sangat ditunggu setelah seri terakhir mereka 
                    rilis 10 tahun yang lalu yaitu Grand Theft Auto V atau GTA 5. </p>
                    <br>
            <p class="w3-justify">Meski sempat bocor sebelum peluncuran resminya, 
                trailer GTA 6 tetap membuat penggemar kagum akan kualitas grafis yang h
                alus dan begitu realistis. Peningkatan grafis terlihat sangat signifikan, 
                menjawab rasa penasaran para gamer yang sudah menunggu selama satu dekade setelah 
                perilisan GTA 5 tahun 2013. Video berdurasi 90 detik itu pun mengkonfirmasi spekulasi 
                dan rumor yang beredar sebelumnya, bahwa karakter utama GTA 6 adalah seorang wanita. 
                Dalam trailer itu, karakter wanita bernama Lucia akan hadir, menjadi sejarah pertama 
                dalam GTA.</p>
                <br>
            <p class="w3-justify">Masih banyak pertanyaan penggemar yang belum terjawab 
                tentang plot dari Grand Theft Auto 6. Setidaknya penggemar masih harus bersabar, 
                sebab, pada akhir video tersebut tertulis bahwa peluncuran GTA 6 akan dilakukan pada 
                tahun 2025.</p>
                    <br>
        </div>
        <div class="w3-half w3-padding" style="text-align: right;">
            <div class="mySlides w3-display-container w3-center">
                <img src="img/gta6(2).jpeg" alt="GTA 6 Trailer" style="width:92%">
            </div>
            <br>
            <div class="mySlides w3-display-container w3-center">
                <img src="img/gta6.gif" alt="GTA 6 Trailer" style="width:92%">
            </div>
        </div>
    </div>
</div>

</div>

<style>
.w3-row {
    display: flex;
}

.w3-half {
    flex: 1;
}

.w3-card {
        background-color: #000; /* Matte Black */
        color: #FFA500; /* Orange */
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
    }
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\10122790\utslara\resources\views/artikel1.blade.php ENDPATH**/ ?>