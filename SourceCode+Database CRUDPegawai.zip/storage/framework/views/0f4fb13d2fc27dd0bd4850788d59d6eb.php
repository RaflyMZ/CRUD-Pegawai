

<?php $__env->startSection('konten'); ?>
<style>
body {
    background-color: #a9a9a9; 
}
</style>

<br>
<br>
<!-- Page Content Section -->
<div class="w3-content" style="max-width:2000px;margin-top:46px">

  <!-- Artikel Section -->
  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px; margin: auto;" id="band">
    <div class="w3-card w3-padding">
        <h1 class="w3-wide">DATA PROGRAMMER</h1>
        <hr>
        <br>
        <div class="w3-row">
            <div class="w3-half w3-padding">
            <div class="w3-half w3-padding" style="text-align: left;">
                <img src="img/about.jpeg" style="width: 80%; height: 50%" alt="">
            </div>
            
            </div>
           
            <div class="w3-half w3-padding">
                <h3 class="w3-wide">Nama            = Rafly Maulana ZUlyzar</h3>   
                <h3 class="w3-wide">NIM             = 10122790</h3>
                <h3 class="w3-wide">Fakultas        = Teknik dan Ilmu Komputer</h3>
                <h3 class="w3-wide">Jurusan         = Teknik Informatika</h3>
                <h3 class="w3-wide">About Web       = Web artikel sederhana yang memiliki CRUD berupa Login Register</h3>
                <h3 class="w3-wide">Source Berita   =
                    
                    <h4 class="w3-wide"><a href="https://www.antaranews.com/berita/3859587/akhirnya-rilis-trailer-gta-6-konfirmasi-berbagai-rumor">1. Trailer GTA 6</a></h4>
                    <h4 class="w3-wide"><a href="https://revivaltv.id/news/lol/t1-juara-worlds-2023-faker">2. T1 Juara Worlds 2023 Faker</a></h4>
                    <h4 class="w3-wide"><a href="https://duniagames.co.id/discover/article/profil-faker">3. Profil Faker</a></h4>
                    <h4 class="w3-wide"><a href="https://www.liputan6.com/tekno/read/5453330/mengenal-game-a-space-for-the-unbound-game-indonesia-yang-masuk-nominasi-the-game-awards-2023?page=3">4. Game "A Space for the Unbound"</a></h4>
                    <h4 class="w3-wide"><a href="https://nawalakarsa.id/game-teknologi/the-game-awards-2023-selesai-begini-ringkasannya/">5. The Game Awards 2023</a></h4>
                    <h4 class="w3-wide"><a href="https://hypebeast.com/id/2023/10/newjeans-keluarin-single-gods-buat-league-of-legends-world-championship-2023">6. NewJeans Single "Gods" untuk LoL World Championship 2023</a></h4>
                </h3>
         
            </div>
        </div>
    </div>
  </div>
</div>

<style>
.w3-row {
    display: flex;
}

.w3-half {
    flex: 1;
}

.w3-card {
    background-color: #000; /* Matte Black */
    color: #FFA500; /* Orange */
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}
</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\10122790\utslara\resources\views/about.blade.php ENDPATH**/ ?>