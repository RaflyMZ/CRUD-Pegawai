

<?php $__env->startSection('konten'); ?>
<style>
		body {
        	background-color: #a9a9a9;     
   		}

          
</style>

        </style>


<br>
<br>
<!-- Page Content Section -->
<div class="w3-content" style="max-width:2000px;margin-top:46px">

  <!-- Artikel Section -->
  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px; margin: auto;" id="band">

<div class="w3-card w3-padding">
    <h1 class="w3-wide">FAKER RESMI MENJADI GOAT DI LEAGUE OF LEGEND</h1>
    <hr>
    <p class="w3-opacity"><i>Dunia Video Game</i></p>
    
    <br>
    <br>

    <div class="w3-row">
        <div class="w3-half w3-padding">
            <p class="w3-justify">Setelah menjuarai memenangkan WORLD 2023, Lee "FAKER" Sang-Hyeok telah resmi menjadi GOAT dari game league
						of legend dikarenakan sejauh ini hanya dia yang sebagai player
						esport LOL yang memenangkan WORLD sebanyak 4x. Selain WORLD, Faker juga
                    sudah pernah menjuarai League of Legend Champions Korea(LCK) dan Mid Seasonal Internasional(MSI) bersama T1.</p>
                    <br>
                    <p class="w3-justify">Selain Piala beregu, Faker juga sudah mendapatkan beberapa penghargaan
                        pribadi seperti mendapat penghargaan "Best Esport Athlete 2017" 
                        di event game bergengsi yaitu the Game Awards tahun 2017 dan baru ini 
                        kembali terpilih sebagai "Best Esport Athlete 2023" di acara yang sama.
                    </p>
                    <br>
                    <p class="w3-justify">Faker juga mewakili Korea Selatan di bidang eSports di Asian Games 2018
                        dan 2022. Timnya berhasil meraih medali perak di Asian Games 2018. Di Asian Games 2022, 
                        Faker membantu timnya meraih medali emas.  Faker dibebaskan dari wajib militer oleh pemerintah 
                        Korea Selatan atas kontribusinya yang luar biasa. Maka dari itu tak heran jika Lee Sang-Hyeok 
                        atau Faker pantas mendapat julukan the GOAT of League of Legend.
                    </p>
        </div>
        <div class="w3-half w3-padding" style="text-align: right;">
            <div class="mySlides w3-display-container w3-center">
                <img src="img/Faker.jpeg" alt="Faker 1" style="width:92%">
            </div>
            <br>
            <div class="mySlides w3-display-container w3-center">
                <img src="img/faker1.gif" alt="Faker 2" style="width:92%">
            </div>
        </div>
    </div>
</div>

</div>

<style>
.w3-row {
    display: flex;
}

.w3-half {
    flex: 1;
}

.w3-card {
        background-color: #000; /* Matte Black */
        color: #FFA500; /* Orange */
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
    }
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\10122790\utslara\resources\views/artikel3.blade.php ENDPATH**/ ?>