

<?php $__env->startSection('konten'); ?>
<style>
		body {
        	background-color: #a9a9a9;     
   		}

          
</style>

        </style>


<br>
<br>
<!-- Page Content Section -->
<div class="w3-content" style="max-width:2000px;margin-top:46px">

  <!-- Artikel Section -->
  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px; margin: auto;" id="band">

<div class="w3-card w3-padding">
    <h1 class="w3-wide">A SPACE FOR THE UNBOUND MASUK NOMINASI THE GAME AWARDS 2023</h1>
    <hr>
    <p class="w3-opacity"><i>Dunia Video Game</i></p>
    
    <br>
    <br>

    <div class="w3-row">
        <div class="w3-half w3-padding">
            <p class="w3-justify">A space for the unbound masuk nominasi Game Awards 2023. Game yang dibuat
						oleh developer asal indonesia ini masuk nominasi "Games  For Impact" yang dimana 
						pada kategori ini game dianggap berhasil menyampaikan makna atau moral kehidupan
                    yang dalam sehingga game tersebut pantas mendapatkan penghargaan itu.</p>
                    <br>
                    <p class="w3-justify">Dalam nominasi kali ini, game produksi Mojiken dan 
                        penerbit Toge Productions ini harus bersaing dengan game lain  
                        seperti Chants of Sennaar, Goodbye Volcano High, Tchia, Terra Nil, dan Venba. 
                        Masuknya game tersebut ke dalam daftar kandidat The Game Awards 2023 jelas 
                        menjadi kabar positif bagi industri game dalam negeri. Terlebih lagi, 
                        game ini telah mendapatkan feedback positif sejak  pertama kali dirilis 
                        pada Januari 2023.</p>
                        <br>
                    <p class="w3-justify">Gamer pun dapat memberikan suaranya untuk mendukung 
                        A Space for the Unbound di The Game Awards 2023 melalui voting di melalui
                         situs thegameawards.com</p>

        </div>
        <div class="w3-half w3-padding" style="text-align: right;">
            <div class="mySlides w3-display-container w3-center">
                <img src="img/asfthu.webp" alt="asfthu 1" style="width:92%">
            </div>
            <br>
            <div class="mySlides w3-display-container w3-center">
                <img src="img/cat.gif" alt="asfthu 2" style="width:92%">
            </div>
        </div>
    </div>
</div>

</div>

<style>
.w3-row {
    display: flex;
}

.w3-half {
    flex: 1;
}

.w3-card {
        background-color: #000; /* Matte Black */
        color: #FFA500; /* Orange */
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
    }
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\10122790\utslara\resources\views/artikel4.blade.php ENDPATH**/ ?>