

<?php $__env->startSection('konten'); ?>
<style>
		body {
        	background-color: #a9a9a9;     
   		}

          
</style>

        </style>


<br>
<br>
<!-- Page Content Section -->
<div class="w3-content" style="max-width:2000px;margin-top:46px">

  <!-- Artikel Section -->
  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px; margin: auto;" id="band">

<div class="w3-card w3-padding">
    <h1 class="w3-wide">NEWJEANS MERILIS SINGLE BERJUDUL "GODS" UNTUK WORLD 2023</h1>
    <hr>
    <p class="w3-opacity"><i>Dunia Video Game</i></p>
    
    <br>
    <br>

    <div class="w3-row">
        <div class="w3-half w3-padding">
            <p class="w3-justify">NewJeans merilis single berjudul "GODS" untuk turnamen League of Legend 
                bergengsi yaitu WORLD 2023. Yang membuat lagu ini begitu hype dikarenakan 
                lagu ini sendiri dinyanyikan oleh group K-POP terkenal yaitu NewJeans dimana
            band ini yang merilis lagu Super Shy.</p>
            <br>
            <p class="w3-justify">“GODS” sendiri jadi representasi bagaimana para pemain esport League of Legend bisa terus 
                berkembang hingga akhirnya jadi penguasa game ini alias jadi gods sendiri. Seperti biasa, 
                NewJeans selalu sukses memberikan hasil yang perfect balance dari musik dan suara mereka. 
                Tapi yang paling menarik dari single ini terlihat dari MV “GODS” sendiri.</p>
                <br>
            <p class="w3-justify">MV single ini merekam perjalanan Deft yang tahun lalu bisa 
                membawa timnya juara Worlds 2022. Storyline-nya sendiri membahas bagaimana Deft                 jadi pro player sejak SMA, lalu menemukan berbagai masalah hingga akhirnya 
                menjadi pro player sejak bangku SMA dengan berbagai rintangan yang dihadapinya.</p>
        </div>
        <div class="w3-half w3-padding" style="text-align: right;">
            <div class="mySlides w3-display-container w3-center">
                <img src="img/god.jpeg" alt="GODS" style="width:92%">
            </div>
            <br>
            <div class="mySlides w3-display-container w3-center">
                <img src="img/deft.webp" alt="GTA 6 Trailer" style="width:92%">
            </div>
        </div>
    </div>
</div>

</div>

<style>
.w3-row {
    display: flex;
}

.w3-half {
    flex: 1;
}

.w3-card {
        background-color: #000; /* Matte Black */
        color: #FFA500; /* Orange */
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
    }
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\10122790\utslara\resources\views/artikel6.blade.php ENDPATH**/ ?>